<?php
/*
Plugin Name: Eclat Testimonial
Plugin URI: http://www.elartica.com/plugins/testimonials/
Description: With the help of this plugin you can add section testimonials
Author: Elartica Team
Author URI: http://www.elartica.com
Text Domain: eclat-testimonials
Domain Path: /languages/
Version: 1.0.0
*/

define( 'ECLAT_TESTIMONIALS_VERSION', '1.0.0' );
define( 'ECLAT_TESTIMONIALS_TAXONOMY', 'testimonial-category');
define( 'ECLAT_TESTIMONIALS_POST_TYPE', 'testimonial');
define( 'ECLAT_TESTIMONIALS_PLUGIN_PATH', dirname(__FILE__));
define( 'ECLAT_TESTIMONIALS_PLUGIN_URL', untrailingslashit( plugins_url( '/', __FILE__ ) ));
define( 'ECLAT_TESTIMONIALS_PLUGIN_SHORTCODES_PATH', ECLAT_TESTIMONIALS_PLUGIN_PATH .  '/includes/ShortCodes' );

// Loaded this plugin
add_action( 'plugins_loaded', function(){
    load_plugin_textdomain( 'eclat-testimonials', false, dirname( plugin_basename( __FILE__ ) ). '/languages/' );
} );

include_once(ECLAT_TESTIMONIALS_PLUGIN_PATH.'/includes/functions.php');

// Start up this plugin
add_action( 'init', function()
{
    eclat_testimonials_register_post_types();
    eclat_testimonials_register_taxonomy();

    add_filter( 'manage_edit-testimonial_columns', 'eclat_testimonials_edit_columns' );
    add_action( 'manage_posts_custom_column', 'eclat_testimonials_custom_columns' );

    add_theme_support('post-thumbnails');
    set_post_thumbnail_size(110, 110, true);

    // for thumbnail preview in the admin screen
    if (function_exists('add_theme_support') && "testimonial" == eclat_testimonials_get_current_post_type())
    {
        add_filter( 'manage_posts_columns', 'eclat_testimonials_add_thumbnail_column' );
        add_action( 'manage_posts_custom_column', 'eclat_testimonials_add_thumbnail_value', 10, 2 );
    }

    // Add Extra Custom Fields to the Post Type Add / Edit screen
    add_action( 'admin_init', 'eclat_testimonials_admin_init' );
    add_action( 'save_post', 'eclat_testimonials_save_details' );

    // Add Columns to the Testimonials Categories Screen
    add_filter("manage_edit-testimonial-category_columns", 'eclat_testimonials_manage_categories');
    add_filter("manage_testimonial-category_custom_column", 'eclat_testimonials_manage_columns', 10, 3);

    // load shortcodes
    include_once(ECLAT_TESTIMONIALS_PLUGIN_SHORTCODES_PATH.'/eclat-testimonials.php');

    // Visual Composer
    if (class_exists('WPBakeryVisualComposerAbstract'))
    {
        include_once(ECLAT_TESTIMONIALS_PLUGIN_SHORTCODES_PATH.'/VisualComposer/eclat-testimonials.php');
    }

} );