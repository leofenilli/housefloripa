<?php
/**
 * @package   Eclat Testimonials
 * @author    Elartica Team http://www.elartica.com
 * @copyright Copyright (C) Elartica Team
 * @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
 */

// register post types
function eclat_testimonials_register_post_types()
{
    $testimonial_labels = array(
        'name'                  => esc_html__('Testimonials', 'post type general name', 'eclat-testimonials'),
        'singular_name'         => esc_html__('Testimonial', 'post type singular name', 'eclat-testimonials'),
        'add_new'               => esc_html__('Add New', 'eclat-testimonials'),
        'add_new_item'          => esc_html__('Add New Testimonial', 'eclat-testimonials'),
        'edit_item'             => esc_html__('Edit Testimonial', 'eclat-testimonials'),
        'new_item'              => esc_html__('New Testimonial', 'eclat-testimonials'),
        'all_items' 			=> esc_html__('All Testimonials', 'eclat-testimonials'),
        'view_item'             => esc_html__('View Testimonial', 'eclat-testimonials'),
        'search_items'          => esc_html__('Search Testimonials', 'eclat-testimonials'),
        'not_found'             => esc_html__('Nothing Found', 'eclat-testimonials'),
        'not_found_in_trash'    => esc_html__('Nothing found in Trash', 'eclat-testimonials'),
        'parent_item_colon'     => ''
    );

    $testimonial_args = array(
        'labels'                => $testimonial_labels,
        'singular_label'        => esc_html__('testimonial', 'eclat-testimonials'),
        'public'                => true,
        'show_ui'               => true,
        'show_in_nav_menus'     => false,
        'capability_type'       => 'post',
        'hierarchical'          => false,
        'rewrite'               => true,
        'menu_icon'				=> 'dashicons-format-status',
        'menu_position'			=> 20,
        'exclude_from_search' 	=> true,
        'supports'              => array('title', 'excerpt', 'editor', 'thumbnail')
    );

    register_post_type('testimonial',$testimonial_args);
}

// register taxonomy
function eclat_testimonials_register_taxonomy()
{
    $taxonomy_labels = array(
        'name'                  => esc_html__('Testimonial Categories', 'eclat-testimonials'),
        'singular_name'         => esc_html__('Testimonial Category', 'eclat-testimonials'),
        'all_items' 			=> esc_html__('All Testimonial Categories', 'eclat-testimonials'),
        'add_new_item'          => esc_html__('Add New Testimonial Category', 'eclat-testimonials'),
        'edit_item'             => esc_html__('Edit Testimonial Category', 'eclat-testimonials'),
        'new_item'              => esc_html__('New Testimonial Category', 'eclat-testimonials'),
        'view_item'             => esc_html__('View Testimonial Category', 'eclat-testimonials'),
        'search_items'          => esc_html__('Search Testimonial Category', 'eclat-testimonials'),
        'not_found'             => esc_html__('Nothing Found', 'eclat-testimonials'),
        'not_found_in_trash'    => esc_html__('Nothing found in Trash', 'eclat-testimonials'),
        'parent_item_colon'     => ''
    );

    register_taxonomy("testimonial-category", array("testimonial"), array(
        "hierarchical" => true,
        "labels" => $taxonomy_labels,
        "rewrite" => array("slug" => "view", "hierarchical" => false, "with_front" => false)
    ));
}

// add custom columns to the admin acreen
function eclat_testimonials_custom_columns($column)
{
    global $post;
    $custom = get_post_custom();

    if ("post_id" == $column) echo $post->ID;
    elseif ("description" == $column) echo substr($post->post_content, 0, 100).'...';
    elseif ("client-name" == $column)  echo $custom["client-name"][0];
    elseif ("thumbnail" == $column) echo $post->post_thumbnail;
    elseif("category" == $column)
    {
        $categories = get_the_terms(0, "testimonial-category");
        if(!is_array($categories)) return;
        $category = reset($categories);
        if(is_object($category))
        {
            echo $category->name;
        }
    }
}

function eclat_testimonials_edit_columns($columns)
{
    $columns = array(
        "cb" 			=> "<input type=\"checkbox\" />",
        "title" 		=> esc_html__('Title', 'eclat-testimonials'),
        "client-name" 	=> esc_html__('Client', 'eclat-testimonials'),
        "thumb" 	    => esc_html__('Thumbnail', 'eclat-testimonials'),
        "description" 	=> esc_html__('Description', 'eclat-testimonials'),
        "category" 		=> esc_html__('Category', 'eclat-testimonials'),
        "date" 			=> esc_html__('Date', 'eclat-testimonials'),
    );
    return $columns;
}

// for thumbnail preview in the admin screen
function eclat_testimonials_add_thumbnail_column($cols)
{
    $cols['thumb'] = esc_html__('Thumbnail', 'eclat-testimonials');
    return $cols;
}

function eclat_testimonials_add_thumbnail_value($column_name, $post_id)
{
    $width = (int) 110;
    $height = (int) 110;

    if ( 'thumb' == $column_name )
    {
        $thumbnail_id = get_post_meta( $post_id, '_thumbnail_id', true );
        $attachments = get_children( array('post_parent' => $post_id, 'post_type' => 'attachment', 'post_mime_type' => 'image') );

        if ($thumbnail_id) {
            $thumb = wp_get_attachment_image($thumbnail_id, array($width, $height), true);
        }
        elseif ($attachments)
        {
            foreach ( $attachments as $attachment_id => $attachment )
            {
                $thumb = wp_get_attachment_image( $attachment_id, array($width, $height), true );
            }
        }

        if ( isset($thumb) && $thumb )
        {
            echo $thumb;
        }
        else
        {
            echo esc_html__('None', 'eclat-testimonials');
        }
    }
}

// Add Extra Custom Fields to the Post Type Add / Edit screen
function eclat_testimonials_admin_init()
{
    add_meta_box("testimonials_meta_box", "Testimonials Item Options", "eclat_testimonials_meta_options", "testimonial", "normal", "low");
}

function get_eclat_testimonials_meta_boxes_fields()
{
    $meta_boxes_fields = array(
        'client-name' => array(
            'label' => esc_html__( 'Client', 'eclat-testimonials' ),
            'desc' => esc_html__( 'The Clients Name', 'eclat-testimonials' ),
            'type' => 'text',
        ),
        'client-post' => array(
            'label' => esc_html__( 'Position', 'eclat-testimonials' ),
            'desc' => esc_html__( 'The Clients Position', 'eclat-testimonials' ),
            'type' => 'text',
        ),
        'client-email' => array(
            'label' => esc_html__( 'Email', 'eclat-testimonials' ),
            'desc' => esc_html__( 'The Clients Email', 'eclat-testimonials' ),
            'type' => 'text',
        ),
        'company-website' => array(
            'label' => esc_html__( 'Website', 'eclat-testimonials' ),
            'desc' => esc_html__( 'The Company Website', 'eclat-testimonials' ),
            'type' => 'text',
        ),
        'company-name' => array(
            'label' => esc_html__( 'Company Name', 'eclat-testimonials' ),
            'desc' => esc_html__( 'The Company Name', 'eclat-testimonials' ),
            'type' => 'text',
        )
    );

    return $meta_boxes_fields;
}

function eclat_testimonials_meta_options()
{
    $meta_boxes_fields = get_eclat_testimonials_meta_boxes_fields();
    global $post;
    echo '<input type="hidden" name="eclat_testimonials_meta_boxes_nonce" value="'.wp_create_nonce('eclat_testimonials_meta_boxes_nonce').'" />';

    echo '<table class="form-table">';
    foreach ($meta_boxes_fields as $key => $field)
    {
        $meta = get_post_meta($post->ID, $key, true);
        echo '<tr>
                <th><label for="'.$key.'">'.$field['label'].'</label></th>
                <td>';
        switch($field['type']) {
            case 'text':
                echo '<input type="text" name="'.$key.'" id="'.$key.'" value="'.$meta.'" size="30" /><br /><span class="description">'.$field['desc'].'</span>';
                break;
            case 'checkbox':
                echo '<input type="checkbox" name="'.$key.'" id="'.$key.'" '.($meta ? 'checked="checked"' : '').'/><label for="'.$key.'">'.$field['desc'].'</label>';
                break;
            case 'colorpicker':
                wp_enqueue_script('wp-color-picker');
                wp_enqueue_style( 'wp-color-picker' );
                echo '<input name="'.$key.'" type="text" id="'.$key.'" value="'.($meta ? $meta : '#fab000').'" data-default-color="#fab000" size="30">
                <script type="text/javascript">
                jQuery(document).ready(function($) { $("#'.$key.'").wpColorPicker(); });
                </script>
                ';
                break;
            case 'select':
                echo '<select name="'.$key.'" id="'.$key.'">';
                foreach ($field['options'] as $option) {
                    echo '<option', $meta == $option['value'] ? ' selected="selected"' : '', ' value="'.$option['value'].'">'.$option['label'].'</option>';
                }
                echo '</select><br /><span class="description">'.$field['desc'].'</span>';
                break;
        }
        echo '</td></tr>';
    }
    echo '</table>';
}

function eclat_testimonials_save_details($post_id)
{
    $meta_boxes_fields = get_eclat_testimonials_meta_boxes_fields();

    if(!isset($_REQUEST['eclat_testimonials_meta_boxes_nonce']))
        return $post_id;

    $nonce = $_REQUEST['eclat_testimonials_meta_boxes_nonce'];

    if (!wp_verify_nonce($nonce, 'eclat_testimonials_meta_boxes_nonce'))
        return $post_id;

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
        return $post_id;

    if ('page' == $_REQUEST['post_type'])
    {
        if (!current_user_can('edit_page', $post_id))
            return $post_id;
    }
    elseif (!current_user_can('edit_post', $post_id))
    {
        return $post_id;
    }

    foreach ($meta_boxes_fields as $key => $field)
    {
        $old = get_post_meta($post_id, $key, true);
        $new = $_REQUEST[$key];

        if ($new && $new != $old)
        {
            update_post_meta($post_id, $key, $new);
        }
        elseif ('' == $new && $old)
        {
            delete_post_meta($post_id, $key, $old);
        }
    }
}

// Add Columns to the Testimonials Categories Screen
function eclat_testimonials_manage_categories($columns)
{
    $new_columns = array(
        'cb' 			=> '<input type="checkbox" />',
        'ID'			=> esc_html__('ID', 'eclat-testimonials'),
        'name' 			=> esc_html__('Name', 'eclat-testimonials'),
        'slug' 			=> esc_html__('Slug', 'eclat-testimonials'),
        'shortcode' 	=> esc_html__('Shortcode', 'eclat-testimonials'),
        'posts' 		=> esc_html__('Posts', 'eclat-testimonials')
    );
    return $new_columns;
}

function eclat_testimonials_manage_columns($output, $column_name, $id)
{
    $column = get_term($id, 'testimonial-category');

    switch ($column_name)
    {
        case 'shortcode':
            $output .= '[eclat_testimonials category="'.$id.'"]';
            break;
        case 'ID':
            $output .= $id;
            break;
        default:
            break;
    }
    return $output;
}

function eclat_testimonials_get_website($website) {
    if (!preg_match("~^(?:f|ht)tps?://~i", $website)) {
        $url = "http://" . $website;
    } else {
        $url = $website;
    }
    return $url;
}

// gets the current post type in the WordPress Admin
function eclat_testimonials_get_current_post_type() {
    global $post, $typenow, $current_screen;

    //we have a post so we can just get the post type from that
    if ( $post && $post->post_type )
        return $post->post_type;

    //check the global $typenow - set in admin.php
    elseif( $typenow )
        return $typenow;

    //check the global $current_screen object - set in sceen.php
    elseif( $current_screen && $current_screen->post_type )
        return $current_screen->post_type;

    //lastly check the post_type querystring
    elseif( isset( $_REQUEST['post_type'] ) )
        return sanitize_key( $_REQUEST['post_type'] );

    //we do not know the post type!
    return null;
}

?>