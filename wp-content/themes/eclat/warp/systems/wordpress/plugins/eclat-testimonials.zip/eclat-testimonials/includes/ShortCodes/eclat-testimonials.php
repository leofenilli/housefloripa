<?php

// [eclat_testimonials]
function eclat_testimonials_shortcode( $params = array() )
{
    extract( shortcode_atts( array(
        'number' => '10',
        'category' => 'all',
        'title' => 'yes',
        'images' => 'yes',
        'date' => 'yes',
        'orderby' => 'date',
        'order' => 'desc',
        'scrollspy' => 'no',
        'scrollspy_class' => '',
        'scrollspy_repeat' => 'false',
        'scrollspy_delay' => '300'
    ), $params ) );

    if(isset($number) && $number != '')
    {
        $limit = $number;
    }
    else
    {
        $limit = "10";
    }

    if(isset($category) && $category != '')
    {
        $term = get_term_by('id', $category, 'testimonial-category');

        $args = array(
            $term->taxonomy 	=> $term->slug,
            'post_type' 		=> 'testimonial',
            'posts_per_page' 	=> $limit,
            'nopaging'          => false,
            'paged'             => get_query_var('paged'),
            'orderby'         	=> $orderby,
            'order'             => $order,
            'post_status'     	=> 'publish'
        );
    }
    else
    {
        $args = array(
            'post_type' 		=> 'testimonial',
            'posts_per_page' 	=> $limit,
            'nopaging'          => false,
            'paged'             => get_query_var('paged'),
            'orderby'         	=> $orderby,
            'order'             => $order,
            'post_status'     	=> 'publish'
        );
    }

    if($scrollspy == "yes" && $scrollspy_class != ''){
        $scrollspy_html = ' data-uk-scrollspy="{cls:\'' . $scrollspy_class . ' uk-invisible\', target:\'.uk-width-1-1\', repeat: ' . $scrollspy_repeat . ', delay:' . $scrollspy_delay . '}"';
        $scrollspy_class = ' uk-invisible';
    } else {
        $scrollspy_html = $scrollspy_class = '';
    }

    ob_start();

    $testimonials = new WP_Query( $args );

    if ( $testimonials->have_posts() ) : ?>

        <div class="uk-grid testimonials"<?php echo $scrollspy_html; ?>>

        <?php while ( $testimonials->have_posts() ) : $testimonials->the_post(); ?>

            <div class="uk-width-1-1<?php echo $scrollspy_class; ?>">

                <article id="testimonials-item-<?php the_ID(); ?>" class="uk-testimonials">

                    <?php if (has_post_thumbnail()) { ?>
                        <div class="uk-testimonials-thumbnail">
                            <?php the_post_thumbnail(array(200, 200), array('class' => '')); ?>
                        </div>
                    <?php } ?>

                    <div class="uk-testimonials-content">
                        <?php if($date == "yes") { ?>
                            <div class="uk-testimonials-top-meta">
                                <div class="uk-testimonials-date"><span class="time"><?php echo '<time datetime="'.get_the_date('Y-m-d').'">'.get_the_date().'</time>'; ?></span></div>
                            </div>
                        <?php } ?>

                        <?php if($title == "no") { ?>
                            <h2 class="uk-testimonials-title"><?php the_title(); ?></h2>
                        <?php } ?>

                        <?php the_content(''); ?>

                        <div class="uk-testimonials-post-meta">
                        <?php
                            $client_name = get_post_meta( get_the_ID(), 'client-name' );
                            $client_post = get_post_meta( get_the_ID(), 'client-post' );
                            $company_website = get_post_meta( get_the_ID(), 'company-website' );
                            $company_name = get_post_meta( get_the_ID(), 'company-name' );

                            if(is_array($client_name) && isset($client_name[0]) && $client_name[0]) echo '<span class="uk-testimonials-client-name">'.esc_html($client_name[0]).',</span>';

                            if(is_array($client_post) && isset($client_post[0]) && $client_post[0]) echo '<span class="uk-testimonials-client-post">'.esc_html($client_post[0]).'</span>';

                            if(is_array($company_website) && isset($company_website[0]) && $company_website[0] && is_array($company_name) && isset($company_name[0]) && $company_name[0])
                            {
                                echo '<a class="uk-testimonials-company-website" href="'.eclat_testimonials_get_website($company_website[0]).'" target="blank">'.esc_html($company_name[0]).'</a>';
                            }
                            elseif(is_array($company_name) && isset($company_name[0]) && $company_name[0])
                            {
                                echo '<span class="uk-testimonials-company-name">'.esc_html($company_name[0]).'</span>';
                            }
                        ?>
                        </div>
                    </div>

                </article>

            </div>

        <?php endwhile; ?>

        </div>

        <?php require_once 'pagination.php';?>

    <?php

    endif;

    wp_reset_query();
    $content = ob_get_contents();
    ob_end_clean();

    return $content;
}

add_shortcode("eclat_testimonials", "eclat_testimonials_shortcode");

// [eclat_testimonials]
function eclat_testimonials_slider_shortcode( $params = array() )
{
    extract( shortcode_atts( array(
        'number' => '10',
        'category' => 'all',
        'title' => 'yes',
        'images' => 'yes',
        'date' => 'yes',
        'orderby' => 'date',
        'order' => 'desc',
        'slider'     => 'default',
        'animation' => 'fade',
        'animation_owl' => 'fade',
        'autoplay' => 'false',
        'pause' => 'true',
        'autoplayinterval' => '7000'
    ), $params ) );

    if(isset($number) && $number != '')
    {
        $limit = $number;
    }
    else
    {
        $limit = "10";
    }

    if(isset($category) && $category != '')
    {
        $term = get_term_by('id', $category, 'testimonial-category');

        $args = array(
            $term->taxonomy 	=> $term->slug,
            'post_type' 		=> 'testimonial',
            'posts_per_page' 	=> $limit,
            'orderby'         	=> $orderby,
            'order'             => $order,
            'post_status'     	=> 'publish'
        );
    }
    else
    {
        $args = array(
            'post_type' 		=> 'testimonial',
            'posts_per_page' 	=> $limit,
            'orderby'         	=> $orderby,
            'order'             => $order,
            'post_status'     	=> 'publish'
        );
    }

    ob_start();

    $testimonials = new WP_Query( $args );

    if ( $testimonials->have_posts() ) : ?>

    <div class="tm-testimonials-slider">
        <div class="uk-container uk-container-center">
            <?php if($slider == 'default') { ?>
            <div data-uk-slideset="{default: 1, animation: '<?php echo esc_attr($animation); ?>', duration: 200, autoplay: '<?php echo esc_attr($autoplay); ?>', pauseOnHover: '<?php echo esc_attr($pause); ?>', autoplayInterval: '<?php echo esc_attr($autoplayinterval); ?>'}">
                <div class="uk-slidenav-position">
                    <ul class="uk-slideset">
            <?php } else { ?>
                <div class="owl-testimonials-slider" data-owl-slideset="{default: 1, animation: '<?php echo esc_attr($animation_owl); ?>', autoplay: '<?php echo esc_attr($autoplay); ?>', pauseOnHover: '<?php echo esc_attr($pause); ?>', autoplayInterval: '<?php echo esc_attr($autoplayinterval); ?>'}">
            <?php } ?>

                    <?php while ( $testimonials->have_posts() ) : $testimonials->the_post(); ?>

                        <?php if($slider == 'default') { ?><li><?php } else { ?><div><?php } ?>

                            <div id="testimonials-item-<?php the_ID(); ?>" class="uk-testimonials">

                                <?php if (has_post_thumbnail()) { ?>
                                    <div class="uk-testimonials-thumbnail">
                                        <?php the_post_thumbnail(array(200, 200), array('class' => '')); ?>
                                    </div>
                                <?php } ?>

                                <div class="uk-testimonials-content">
                                    <?php if($date == "yes") { ?>
                                        <div class="uk-testimonials-top-meta">
                                            <div class="uk-testimonials-date"><span class="time"><?php echo '<time datetime="'.get_the_date('Y-m-d').'">'.get_the_date().'</time>'; ?></span></div>
                                        </div>
                                    <?php } ?>

                                    <?php if($title == "no") { ?>
                                        <h2 class="uk-testimonials-title"><?php the_title(); ?></h2>
                                    <?php } ?>

                                    <?php the_content(''); ?>

                                    <div class="uk-testimonials-post-meta">
                                        <?php
                                        $client_name = get_post_meta( get_the_ID(), 'client-name' );
                                        $client_post = get_post_meta( get_the_ID(), 'client-post' );
                                        $company_website = get_post_meta( get_the_ID(), 'company-website' );
                                        $company_name = get_post_meta( get_the_ID(), 'company-name' );

                                        if(is_array($client_name) && isset($client_name[0]) && $client_name[0]) echo '<span class="uk-testimonials-client-name">'.esc_html($client_name[0]).',</span>';

                                        if(is_array($client_post) && isset($client_post[0]) && $client_post[0]) echo '<span class="uk-testimonials-client-post">'.esc_html($client_post[0]).'</span>';

                                        if(is_array($company_website) && isset($company_website[0]) && $company_website[0] && is_array($company_name) && isset($company_name[0]) && $company_name[0])
                                        {
                                            echo '<a class="uk-testimonials-company-website" href="'.eclat_testimonials_get_website($company_website[0]).'" target="blank">'.esc_html($company_name[0]).'</a>';
                                        }
                                        elseif(is_array($company_name) && isset($company_name[0]) && $company_name[0])
                                        {
                                            echo '<span class="uk-testimonials-company-name">'.esc_html($company_name[0]).'</span>';
                                        }
                                        ?>
                                    </div>
                                </div>

                            </div>

                        <?php if($slider == 'default') { ?></li><?php } else { ?></div><?php } ?>

                    <?php endwhile; ?>

            <?php if($slider == 'default') { ?>
                    </ul>
                </div>
                <ul class="uk-slideset-nav uk-dotnav uk-flex-left"></ul>
            </div>
            <?php } else { ?>
                </div>
            <?php } ?>
        </div>
    </div>
    <?php

    endif;

    wp_reset_query();
    $content = ob_get_contents();
    ob_end_clean();

    return $content;
}

add_shortcode("eclat_testimonials_slider", "eclat_testimonials_slider_shortcode");

