<?php

$category_list = get_terms('testimonial-category', array(
    'hide_empty' 	=> false,
    'order_by'		=> 'name',
    'pad_counts'	=> true
));

$category_list_array = array( esc_html__('Show All', 'eclat-testimonials') => 'all' );

foreach($category_list as $category)
{
    $category_list_array[htmlspecialchars_decode($category->name) . ' (' . $category->count . ')'] = $category->term_id;
}

// [eclat_testimonials]
vc_map(array(
    "name"			=> esc_html__( "Testimonials", "eclat-testimonials" ),
    "category"		=> 'Content',
    "description"	=> esc_html__( "Add a testimonials list", "eclat-testimonials" ),
    "base"			=> "eclat_testimonials",
    "class"			=> "",
    "icon"			=> "eclat_testimonials",

    "params" 	=> array(

        array(
            "type"			=> "textfield",
            "holder"		=> "div",
            "class" 		=> "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=> esc_html__( "Number of testimonials to show.", "eclat-testimonials" ),
            "param_name"	=> "number",
            "value"			=> "10"
        ),

        array(
            "type"			=> "dropdown",
            "holder"		=> "div",
            "class" 		=> "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=> esc_html__( "Category", "eclat-testimonials" ),
            "param_name"	=> "category",
            "value"			=> $category_list_array
        ),

        array(
            "type"			=> "dropdown",
            "holder"		=> "div",
            "class" 		=> "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=> esc_html__( "Hide Title", "eclat-testimonials" ),
            "param_name"	=> "title",
            "value"			=> array(
                esc_html__( "Yes", "eclat-testimonials" )	=> "yes",
                esc_html__( "No", "eclat-testimonials" )	=> "no"
            ),
            "std"			=> "yes",
        ),

        array(
            "type"			=> "dropdown",
            "holder"		=> "div",
            "class" 		=> "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=> esc_html__( "Show Images", "eclat-testimonials" ),
            "param_name"	=> "images",
            "value"			=> array(
                esc_html__( "Yes", "eclat-testimonials" )	=> "yes",
                esc_html__( "No", "eclat-testimonials" )	=> "no"
            ),
            "std"			=> "yes",
        ),

        array(
            "type"			=> "dropdown",
            "holder"		=> "div",
            "class" 		=> "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=> esc_html__( "Show Date", "eclat-testimonials" ),
            "param_name"	=> "date",
            "value"			=> array(
                esc_html__( "Yes", "eclat-testimonials" )	=> "yes",
                esc_html__( "No", "eclat-testimonials" )	=> "no"
            ),
            "std"			=> "yes",
        ),

        array(
            "type"			=> "dropdown",
            "holder"		=> "div",
            "class" 		=> "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=> esc_html__( "Order By", "eclat-testimonials" ),
            "param_name"	=> "orderby",
            "value"			=> array(
                esc_html__( "None", "eclat-testimonials" )			    => "none",
                esc_html__( "Sort by ID", "eclat-testimonials" )		    => "ID",
                esc_html__( "Sort alphabetically", "eclat-testimonials" )	=> "name",
                esc_html__( "Sort by most recent", "eclat-testimonials" )	=> "date",
                esc_html__( "Random", "eclat-testimonials" )	            => "rand"
            ),
            "std"			=> "date"
        ),

        array(
            "type"			=> "dropdown",
            "holder"		=> "div",
            "class" 		=> "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=> esc_html__( "Sorting", "eclat-testimonials" ),
            "param_name"	=> "order",
            "value"			=> array(
                esc_html__( "Descending", "eclat-testimonials" ) => "desc",
                esc_html__( "Crescent", "eclat-testimonials" )	  => "asc"
            ),
            "std"			=> "desc"
        ),

        array(
            "type"          => "dropdown",
            "class"         => "hide_in_vc_editor",
            "admin_label"   => true,
            "heading"       => esc_html__( "Use Scrollspy", "eclat-testimonials" ),
            "param_name"    => "scrollspy",
            "value"         => array(
                esc_html__( "No", "eclat-testimonials" )	=> "no",
                esc_html__( "Yes", "eclat-testimonials" )	=> "yes"
            )
        ),

        array(
            "type"          => "dropdown",
            "class"         => "hide_in_vc_editor",
            "admin_label"   => true,
            "heading"       => esc_html__( "Scrollspy Class", "eclat-testimonials" ),
            "param_name"    => "scrollspy_class",
            "value" => array(
                esc_html__( "The element fades in", "eclat-testimonials" ) => "uk-animation-fade",
                esc_html__( "The element scales up", "eclat-testimonials" ) => "uk-animation-scale-up",
                esc_html__( "The element scales down", "eclat-testimonials" ) => "uk-animation-scale-down",
                esc_html__( "The element slides in from the top", "eclat-testimonials" ) => "uk-animation-slide-top",
                esc_html__( "The element slides in from the bottom", "eclat-testimonials" ) => "uk-animation-slide-bottom",
                esc_html__( "The element slides in from the left", "eclat-testimonials" ) => "uk-animation-slide-left",
                esc_html__( "The element slides in from the Right", "eclat-testimonials" ) => "uk-animation-slide-right",
                esc_html__( "The element shakes", "eclat-testimonials" ) => "uk-animation-shake",
                esc_html__( "The element scales down without fading in", "eclat-testimonials" ) => "uk-animation-scale"
            ),
            "dependency" 	=> Array('element' => "scrollspy", 'value' => array('yes'))
        ),

        array(
            "type"          => "dropdown",
            "class"         => "hide_in_vc_editor",
            "admin_label"   => true,
            "heading"       => esc_html__( "Scrollspy Repeat", "eclat-testimonials" ),
            "param_name"    => "scrollspy_repeat",
            "value"         => array(
                esc_html__( "True", "eclat-testimonials" )      => "true",
                esc_html__( "False", "eclat-testimonials" )     => "false"
            ),
            "dependency" 	=> Array('element' => "scrollspy", 'value' => array('yes')),
            "description"   => esc_html__( "Applies the class everytime the element appears in the viewport.", "eclat-testimonials" )
        ),

        array(
            "type"          => "textfield",
            "class"         => "hide_in_vc_editor",
            "admin_label"   => true,
            "heading"       => esc_html__( "Scrollspy Delay", "eclat-testimonials" ),
            "param_name"    => "scrollspy_delay",
            "value"         => "300",
            "dependency" 	=> Array('element' => "scrollspy", 'value' => array('yes')),
            "description"   => esc_html__( "Adds a delay in milliseconds to the animation.", "eclat-testimonials" )
        )
    )

));

// [eclat_testimonials_slider]
vc_map(array(
    "name"			=> esc_html__( "Testimonials Slider", "eclat-testimonials" ),
    "category"		=> 'Content',
    "description"	=> esc_html__( "Add a testimonials slider", "eclat-testimonials" ),
    "base"			=> "eclat_testimonials_slider",
    "class"			=> "",
    "icon"			=> "eclat_testimonials_slider",

    "params" 	=> array(

        array(
            "type"			=> "textfield",
            "holder"		=> "div",
            "class" 		=> "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=> esc_html__( "Number of testimonials to show.", "eclat-testimonials" ),
            "param_name"	=> "number",
            "value"			=> ""
        ),

        array(
            "type"			=> "dropdown",
            "holder"		=> "div",
            "class" 		=> "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=> esc_html__( "Category", "eclat-testimonials" ),
            "param_name"	=> "category",
            "value"			=> $category_list_array
        ),

        array(
            "type"			=> "dropdown",
            "holder"		=> "div",
            "class" 		=> "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=> esc_html__( "Hide Title", "eclat-testimonials" ),
            "param_name"	=> "title",
            "value"			=> array(
                esc_html__( "Yes", "eclat-testimonials" )	=> "yes",
                esc_html__( "No", "eclat-testimonials" )	=> "no"
            ),
            "std"			=> "yes",
        ),

        array(
            "type"			=> "dropdown",
            "holder"		=> "div",
            "class" 		=> "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=> esc_html__( "Show Images", "eclat-testimonials" ),
            "param_name"	=> "images",
            "value"			=> array(
                esc_html__( "Yes", "eclat-testimonials" )	=> "yes",
                esc_html__( "No", "eclat-testimonials" )	=> "no"
            ),
            "std"			=> "yes",
        ),

        array(
            "type"			=> "dropdown",
            "holder"		=> "div",
            "class" 		=> "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=> esc_html__( "Show Date", "eclat-testimonials" ),
            "param_name"	=> "date",
            "value"			=> array(
                esc_html__( "Yes", "eclat-testimonials" )	=> "yes",
                esc_html__( "No", "eclat-testimonials" )	=> "no"
            ),
            "std"			=> "yes",
        ),

        array(
            "type"			=> "dropdown",
            "holder"		=> "div",
            "class" 		=> "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=> esc_html__( "Order By", "eclat-testimonials" ),
            "param_name"	=> "orderby",
            "value"			=> array(
                esc_html__( "None", "eclat-testimonials" )			    => "none",
                esc_html__( "Sort by ID", "eclat-testimonials" )		    => "ID",
                esc_html__( "Sort alphabetically", "eclat-testimonials" )	=> "name",
                esc_html__( "Sort by most recent", "eclat-testimonials" )	=> "date",
                esc_html__( "Random", "eclat-testimonials" )	            => "rand"
            ),
            "std"			=> "date"
        ),

        array(
            "type"			=> "dropdown",
            "holder"		=> "div",
            "class" 		=> "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=> esc_html__( "Sorting", "eclat-testimonials" ),
            "param_name"	=> "order",
            "value"			=> array(
                esc_html__( "Descending", "eclat-testimonials" ) => "desc",
                esc_html__( "Crescent", "eclat-testimonials" )	  => "asc"
            ),
            "std"			=> "desc"
        ),

        array(
            "type"			=> "dropdown",
            "class" 		=> "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=>  esc_html__( "How to use the slider?", "eclat-testimonials" ),
            "param_name"	=> "slider",
            "value"			=> array(
                esc_html__( "Default uikit Slideset", "eclat-testimonials" ) => "default",
                esc_html__( "Owl Carousel", "eclat-testimonials" )	          => "owl"
            ),
            "std"			=> "default"
        ),

        array(
            "type"          => "dropdown",
            "class"         => "hide_in_vc_editor",
            "admin_label"   => true,
            "heading"       => esc_html__( "Animation", "eclat-testimonials" ),
            "param_name"    => "animation",
            "value" => array(
                esc_html__( "The items fade in and out.", "eclat-testimonials" ) => "fade",
                esc_html__( "The items scale up and down.", "eclat-testimonials" ) => "scale",
                esc_html__( "The items slide to and from the top.", "eclat-testimonials" ) => "slide-top",
                esc_html__( "The items slide to and from the bottom.", "eclat-testimonials" ) => "slide-bottom",
                esc_html__( "The items slide to the side.", "eclat-testimonials" ) => "slide-horizontal",
                esc_html__( "The items slide vertically.", "eclat-testimonials" ) => "slide-vertical"
            ),
            "dependency" 	=> Array(
                "element"   => "slider",
                "value"     => array("default")
            ),
            "description"   => esc_html__( "You can add animations which can be used to display the next set of items.", "eclat-testimonials" )
        ),

        array(
            "type"          => "dropdown",
            "class"         => "hide_in_vc_editor",
            "admin_label"   => true,
            "heading"       =>  esc_html__( "Animation", "eclat-testimonials" ),
            "param_name"    => "animation_owl",
            "value" => array(
                esc_html__( "The items fade in and out.", "eclat-testimonials" ) => "fade",
                esc_html__( "The items slide to the side.", "eclat-testimonials" ) => "backSlide",
                esc_html__( "The items slide to and from the top.", "eclat-testimonials" ) => "goDown",
                esc_html__( "The items scale up and down.", "eclat-testimonials" ) => "fadeUp",
            ),
            "dependency" 	=> Array(
                "element"   => "slider",
                "value"     => array("owl")
            ),
            "description"   => esc_html__( "You can add animations which can be used to display the next set of items.", "eclat-testimonials" )
        ),

        array(
            "type"			=> "dropdown",
            "class" 		    => "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=> esc_html__( "Auto play", "eclat-testimonials" ),
            "param_name"	    => "autoplay",
            "value"			=> array(
                esc_html__( "No", "eclat-testimonials" )	=> "false",
                esc_html__( "Yes", "eclat-testimonials" )	=> "true"
            ),
            "std"			=> "false",
            "description" => esc_html__( "Defines whether or not the items should switch automatically.", "eclat-testimonials" )
        ),

        array(
            "type"			=> "dropdown",
            "class" 		    => "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=> esc_html__( "Pause on hover", "eclat-testimonials" ),
            "param_name"	    => "pause",
            "value"			=> array(
                esc_html__( "Yes", "eclat-testimonials" )	=> "true",
                esc_html__( "No", "eclat-testimonials" )	=> "false"
            ),
            "std"			=> "true",
            "dependency" 	=> Array(
                "element"   => "autoplay",
                "value"     => array("true")
            ),
            "description" => esc_html__( "Pause autoplay when hovering.", "eclat-testimonials" )
        ),

        array(
            "type"			=> "textfield",
            "class" 		=> "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=> esc_html__( "Autoplay Interval", "eclat-testimonials" ),
            "param_name"	=> "autoplayinterval",
            "value"			=> "7000",
            "std"			=> "7000",
            "dependency" 	=> Array(
                "element"   => "autoplay",
                "value"     => array("true")
            ),
            "description" => esc_html__( "Defines the timespan between switching items.", "eclat-testimonials" )
        ),

    )

));