<?php

// [eclat_portfolio]
function eclat_portfolio_shortcode( $params = array() )
{
    extract( shortcode_atts( array(
        'number' => '1000',
        'category' => 'all',
        'show_filters' => 'yes',
        'show_date' => 'yes',
        'orderby' => 'date',
        'order' => 'desc',
        'styles' => 'default',
        'items_per_row' => '3',
        'gutter' => '20'
    ), $params ) );

    if(isset($number) && $number != '')
    {
        $limit = $number;
    }
    else
    {
        $limit = "1000";
    }

    if(isset($category) && $category != '' && $category != 'all')
    {
        $term = get_term_by('id', $category, 'portfolio-category');

        $args = array(
            $term->taxonomy 	=> $term->slug,
            'post_type' 		=> 'portfolio',
            'posts_per_page' 	=> $limit,
            'nopaging'          => false,
            'paged'             => get_query_var('paged'),
            'orderby'         	=> $orderby,
            'order'             => $order,
            'post_status'     	=> 'publish'
        );
    }
    else
    {
        $args = array(
            'post_type' 		=> 'portfolio',
            'posts_per_page' 	=> $limit,
            'nopaging'          => false,
            'paged'             => get_query_var('paged'),
            'orderby'         	=> $orderby,
            'order'             => $order,
            'post_status'     	=> 'publish'
        );
    }

    ob_start();

    $portfolio_items = new WP_Query( $args );

    if ( $portfolio_items->have_posts() )
    {
        if(isset($category) && $category == 'all' && isset($show_filters) && $show_filters == 'yes')
        {
            while ( $portfolio_items->have_posts() ) : $portfolio_items->the_post();

                $terms = get_the_terms( get_the_ID(), 'portfolio-category' );

                if ( !empty( $terms ) && !is_wp_error( $terms ) )
                {
                    foreach($terms as $term)
                    {
                        $portfolio_categories[$term->slug] = $term->name;
                    }
                }

            endwhile;

            $portfolio_categories = array_unique($portfolio_categories);

            if ( !empty( $portfolio_categories ) && !is_wp_error( $portfolio_categories ) )
            {
                ?>
                <div class="tm-portfolio-filters">
                    <ul id="portfolio-filters" class="uk-subnav">
                        <li data-uk-filter="" class="uk-active"><button class="uk-button"><?php esc_html_e( "Show all", "eclat-portfolio" )?></button></li>
                        <?php foreach ( $portfolio_categories as $key => $value ) {
                            echo '<li data-uk-filter="' . $key . '"><button class="uk-button">' . $value . '</button></li>';
                        } ?>
                    </ul>
                </div>
            <?php
            }

        }

        $item_counter = 0;

        ?>

        <div class="tm-portfolio" data-uk-grid="{gutter: <?php echo esc_attr($gutter); ?>, controls: '#portfolio-filters'}">

            <?php while ( $portfolio_items->have_posts() ) : $portfolio_items->the_post();

                $item_counter++;

                $related_thumb = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'large' );

                $term_slug_class = array();

                if(isset($category) && $category == 'all')
                {
                    $terms_slug = get_the_terms( get_the_ID(), 'portfolio-category' );

                    if ( !empty( $terms_slug ) && !is_wp_error( $terms_slug ) )
                    {
                        foreach ( $terms_slug as $term_slug )
                        {
                            $term_slug_class[] = $term_slug->slug;
                        }
                    }
                }

                if (get_post_meta( get_the_ID(), 'portfolio-background-color', true )) {
                    $portfolio_background_color = get_post_meta( get_the_ID(), 'portfolio-background-color', true );
                } else {
                    $portfolio_background_color = "none";
                }

                if (get_post_meta( get_the_ID(), 'portfolio-text-color', true )) {
                    $portfolio_text_color = get_post_meta( get_the_ID(), 'portfolio-text-color', true );
                } else {
                    $portfolio_text_color = "inherit";
                }

                if (get_post_meta( get_the_ID(), 'portfolio-introtext', true )) {
                    $portfolio_introtext = get_post_meta( get_the_ID(), 'portfolio-introtext', true );
                } else {
                    $portfolio_introtext = "";
                }

                $grid_class = '';

                if($styles == 'grid') {
                    switch ($item_counter) {
                        case 1:
                            $grid_class = "uk-width-1-1 uk-width-small-1-1 uk-width-medium-1-2 portfolio-grid";
                            break;
                        case 6:
                            $grid_class = "uk-width-1-1 uk-width-small-1-1 uk-width-medium-1-2 portfolio-grid";
                            $item_counter = 0;
                            break;
                        default:
                            $grid_class = "uk-width-1-1 uk-width-small-1-2 uk-width-medium-1-4 portfolio-grid";
                    }

                } else {
                    switch ($items_per_row) {

                        case "3":
                            $grid_class = 'uk-width-1-1 uk-width-small-1-2 uk-width-medium-1-3 ';
                            break;

                        case "4":
                            $grid_class = 'uk-width-1-1 uk-width-small-1-2 uk-width-medium-1-3 uk-width-large-1-4 ';
                            break;

                        case "5":
                            $grid_class = 'uk-width-1-1 uk-width-small-1-2 uk-width-medium-1-3 uk-width-large-1-4 uk-width-xlarge-1-5 ';
                            break;
                    }
                }

                ?>

                <div class="tm-portfolio-box<?php echo $grid_class ? ' '.$grid_class : ''; ?>"<?php echo count($term_slug_class) ? 'data-uk-filter="'.implode(',', $term_slug_class).'"' : ''; ?> >
                    <a href="<?php echo get_permalink(get_the_ID()); ?>" style="background: <?php echo $portfolio_background_color; ?>;">

                        <?php if ($related_thumb[0] != "") : ?>
                            <span class="tm-portfolio-thumb" style="background-image: url(<?php echo esc_url($related_thumb[0]); ?>)"></span>
                        <?php endif; ?>

                        <div class="tm-portfolio-content" style="color: <?php echo esc_attr($portfolio_text_color); ?>; padding: 30px <?php echo intval($gutter)+30;?>px 30px 30px">

                            <h2><?php the_title(); ?></h2>
                            <?php if(isset($show_date) && $show_date == 'yes') { ?>
                            <span class="tm-portfolio-date"><?php echo get_the_date(); ?></span>
                            <?php } ?>
                            <div class="uk-overflow-hidden">
                                <div class="tm-portfolio-border" style="background: <?php echo esc_attr($portfolio_text_color); ?>;"></div>
                            </div>
                            <p><?php echo $portfolio_introtext; ?></p>

                        </div>

                    </a>
                </div>

            <?php endwhile; // end of the loop. ?>
        </div>

        <?php require_once 'pagination.php';?>

    <?php

    }

    wp_reset_query();
    $content = ob_get_contents();
    ob_end_clean();

    return $content;
}

add_shortcode("eclat_portfolio", "eclat_portfolio_shortcode");

