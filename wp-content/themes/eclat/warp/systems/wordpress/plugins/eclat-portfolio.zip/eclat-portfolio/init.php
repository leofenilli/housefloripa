<?php
/*
Plugin Name: Eclat Portfolio
Plugin URI: http://www.elartica.com/plugins/portfolio/
Description: With the help of this plugin you can add section portfolio
Author: Elartica Team
Author URI: http://www.elartica.com
Text Domain: eclat-portfolio
Domain Path: /languages/
Version: 1.0.0
*/

define( 'ECLAT_PORTFOLIO_VERSION', '1.0.0' );
define( 'ECLAT_PORTFOLIO_TAXONOMY', 'portfolio-category');
define( 'ECLAT_PORTFOLIO_POST_TYPE', 'portfolio');
define( 'ECLAT_PORTFOLIO_PLUGIN_PATH', dirname(__FILE__));
define( 'ECLAT_PORTFOLIO_PLUGIN_URL', untrailingslashit( plugins_url( '/', __FILE__ ) ));
define( 'ECLAT_PORTFOLIO_PLUGIN_SHORTCODES_PATH', ECLAT_PORTFOLIO_PLUGIN_PATH .  '/includes/ShortCodes' );

// Loaded this plugin
add_action( 'plugins_loaded', function(){
    load_plugin_textdomain( 'eclat-portfolio', false, dirname( plugin_basename( __FILE__ ) ). '/languages/' );
} );

include_once(ECLAT_PORTFOLIO_PLUGIN_PATH.'/includes/functions.php');

// Start up this post type
add_action( 'init', function()
{
    eclat_portfolio_register_post_types();
    eclat_portfolio_register_taxonomy();

    add_filter( 'manage_edit-portfolio_columns', 'eclat_portfolio_edit_columns' );
    add_action( 'manage_posts_custom_column', 'eclat_portfolio_custom_columns' );

    add_theme_support('post-thumbnails');
    set_post_thumbnail_size(110, 110, true);

    // for thumbnail preview in the admin screen
    if ( function_exists('add_theme_support') && "portfolio" == eclat_portfolio_get_current_post_type() )
    {
        add_filter( 'manage_posts_columns', 'eclat_portfolio_add_thumbnail_column' );
        add_action( 'manage_posts_custom_column', 'eclat_portfolio_add_thumbnail_value', 10, 2 );
    }

    // Add Extra Custom Fields to the Post Type Add / Edit screen
    add_action( 'admin_init', 'eclat_portfolio_admin_init' );
    add_action( 'save_post', 'eclat_portfolio_save_details' );

    // Add Columns to the Testimonials Categories Screen
    add_filter("manage_edit-portfolio-category_columns", 'eclat_portfolio_manage_categories');
    add_filter("manage_portfolio-category_custom_column", 'eclat_portfolio_manage_columns', 10, 3);

    // load shortcodes
    include_once(ECLAT_PORTFOLIO_PLUGIN_SHORTCODES_PATH.'/eclat-portfolio.php');

    // Visual Composer
    if (class_exists('WPBakeryVisualComposerAbstract'))
    {
        include_once(ECLAT_PORTFOLIO_PLUGIN_SHORTCODES_PATH.'/VisualComposer/eclat-portfolio.php');
    }


} );