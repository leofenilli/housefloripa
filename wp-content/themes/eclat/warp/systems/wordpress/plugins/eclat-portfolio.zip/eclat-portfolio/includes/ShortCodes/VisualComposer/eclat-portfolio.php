<?php

$category_list = get_terms('portfolio-category', array(
    'hide_empty' 	=> false,
    'order_by'		=> 'name',
    'pad_counts'	=> true
));

$category_list_array = array( esc_html__('Show All', 'eclat-portfolio') => 'all' );

foreach($category_list as $category)
{
    $category_list_array[htmlspecialchars_decode($category->name) . ' (' . $category->count . ')'] = $category->term_id;
}

// [eclat_portfolio]
vc_map(array(
    "name"			=> esc_html__( "Portfolio", "eclat-portfolio" ),
    "category"		=> 'Content',
    "description"	=> esc_html__( "Place Portfolio", "eclat-portfolio" ),
    "base"			=> "eclat_portfolio",
    "class"			=> "",
    "icon"			=> "eclat_portfolio",

    "params" 	=> array(

        array(
            "type"			=> "textfield",
            "holder"		=> "div",
            "class" 		=> "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=> esc_html__( "How many portfolio items would you like to show?", "eclat-portfolio" ),
            "param_name"	=> "number",
            "value"			=> "1000"
        ),

        array(
            "type"			=> "dropdown",
            "holder"		=> "div",
            "class" 		=> "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=> esc_html__( "Portfolio Category", "eclat-portfolio" ),
            "param_name"	=> "category",
            "value"			=> $category_list_array
        ),

        array(
            "type"			=> "dropdown",
            "holder"		=> "div",
            "class" 		=> "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=> esc_html__( "Show Filters?", "eclat-portfolio" ),
            "param_name"	=> "show_filters",
            "value"			=> array(
                esc_html__( "Yes", "eclat-portfolio" )	=> "yes",
                esc_html__( "No", "eclat-portfolio" )	=> "no"
            ),
            "std"			=> "yes",
            "dependency" 	=> Array(
                'element' => "category",
                'value'   => array('all')
            )
        ),

        array(
            "type"			=> "dropdown",
            "holder"		=> "div",
            "class" 		=> "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=> esc_html__( "Show Date?", "eclat-portfolio" ),
            "param_name"	=> "show_date",
            "value"			=> array(
                esc_html__( "Yes", "eclat-portfolio" )	=> "yes",
                esc_html__( "No", "eclat-portfolio" )	=> "no"
            ),
            "std"			=> "yes"
        ),

        array(
            "type"			=> "dropdown",
            "holder"		=> "div",
            "class" 		=> "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=> esc_html__( "Order By", "eclat-portfolio" ),
            "param_name"	=> "orderby",
            "value"			=> array(
                esc_html__( "None", "eclat-portfolio" )			    => "none",
                esc_html__( "Sort by ID", "eclat-portfolio" )		    => "ID",
                esc_html__( "Sort alphabetically", "eclat-portfolio" )	=> "title",
                esc_html__( "Sort by most recent", "eclat-portfolio" )	=> "date",
                esc_html__( "Random", "eclat-portfolio" )	            => "rand"
            ),
            "std"			=> "date"
        ),

        array(
            "type"			=> "dropdown",
            "holder"		=> "div",
            "class" 		=> "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=> esc_html__( "Sorting", "eclat-portfolio" ),
            "param_name"	=> "order",
            "value"			=> array(
                esc_html__( "Descending", "eclat-portfolio" ) => "desc",
                esc_html__( "Crescent", "eclat-portfolio" )	  => "asc"
            ),
            "std"			=> "desc"
        ),

        array(
            "type"			=> "dropdown",
            "holder"		=> "div",
            "class" 		=> "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=> esc_html__( "Grid Layout Styles", "eclat-portfolio" ),
            "param_name"	=> "styles",
            "value"			=> array(
                esc_html__( "Equal Boxes", "eclat-portfolio" )   => "default",
                esc_html__( "Masonry Style", "eclat-portfolio" ) => "grid",
            ),
            "std"			=> "default"
        ),

        array(
            "type"			=> "dropdown",
            "holder"		=> "div",
            "class" 		=> "hide_in_vc_editor",
            "admin_label" 	=> true,
            "heading"		=> esc_html__( "Items per Row", "eclat-portfolio" ),
            "param_name"	=> "items_per_row",
            "value"			=> array(
                "3"	=> "3",
                "4"	=> "4",
                "5"	=> "5"
            ),
            "std"			=> "3",
            "dependency" 	=> Array(
                'element' => "styles",
                'value'   => array('default')
            )
        ),

        array(
            "type"          => "textfield",
            "class"         => "hide_in_vc_editor",
            "admin_label"   => true,
            "heading"       => esc_html__( "Gutter", "eclat-portfolio" ),
            "param_name"    => "gutter",
            "value"         => "20",
            "description"   => esc_html__( "Gutter between columns.", "eclat-portfolio" )
        )
    )

));
