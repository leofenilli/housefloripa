<?php

// [eclat_timeline]
function eclat_timeline_shortcode( $params = array() )
{
    extract( shortcode_atts( array(
        'number' => '10',
        'visible_item' => '5',
        'category' => 'all',
        'orderby' => 'date',
        'order' => 'desc',
        'center' => 'false',
        'infinite' => 'true',
        'autoplay' => 'false',
        'pause' => 'true',
        'autoplayinterval' => '7000',
    ), $params ) );

    if(isset($number) && $number != '')
    {
        $limit = $number;
    }
    else
    {
        $limit = "10";
    }

    $grid_class = '';

    if($visible_item == "5") {
        $grid_class = 'uk-grid-width-1-1 uk-grid-width-small-1-2 uk-grid-width-medium-1-3 uk-grid-width-large-1-4 uk-grid-width-xlarge-1-5';
    } else if($visible_item == "4"){
        $grid_class = 'uk-grid-width-1-1 uk-grid-width-small-1-1 uk-grid-width-medium-1-2 uk-grid-width-large-1-3 uk-grid-width-xlarge-1-4';
    } else if($visible_item == "3") {
        $grid_class = 'uk-grid-width-1-1 uk-grid-width-small-1-1 uk-grid-width-medium-1-1 uk-grid-width-large-1-2 uk-grid-width-xlarge-1-3';
    }

    if(isset($category) && $category != '' && $category != 'all')
    {
        $term = get_term_by('id', $category, 'timeline-category');

        $args = array(
            $term->taxonomy 	=> $term->slug,
            'post_type' 		=> 'timeline',
            'posts_per_page' 	=> $limit,
            'nopaging'          => false,
            'paged'             => get_query_var('paged'),
            'orderby'         	=> $orderby,
            'order'             => $order,
            'post_status'     	=> 'publish'
        );
    }
    else
    {
        $args = array(
            'post_type' 		=> 'timeline',
            'posts_per_page' 	=> $limit,
            'nopaging'          => false,
            'paged'             => get_query_var('paged'),
            'orderby'         	=> $orderby,
            'order'             => $order,
            'post_status'     	=> 'publish'
        );
    }

    ob_start();

    $data_slider = 'data-uk-slider="{center: '.$center.', infinite: '.$infinite.', autoplay: '.$autoplay.', pauseOnHover: '.$pause.', autoplayInterval: '.$autoplayinterval.'}"';

    $timeline_items = new WP_Query( $args );

    $timeline_counter = 0;

    if ( $timeline_items->have_posts() ) : ?>

        <div class="tm-timeline">
            <div class="uk-slidenav-position" <?php echo $data_slider; ?>>
                <div class="uk-slider-container">
                    <ul class="uk-slider <?php echo $grid_class; ?>">

                        <?php while ( $timeline_items->have_posts() ) : $timeline_items->the_post();

                            $timeline_counter++;

                            $related_thumb = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'large' );

                            if (get_post_meta( get_the_ID(), 'timeline-background-color', true )) {
                                $timeline_background_color = get_post_meta( get_the_ID(), 'timeline-background-color', true );
                            } else {
                                $timeline_background_color = "none";
                            }

                            if (get_post_meta( get_the_ID(), 'timeline-text-color', true )) {
                                $timeline_text_color = get_post_meta( get_the_ID(), 'timeline-text-color', true );
                            } else {
                                $timeline_text_color = "inherit";
                            }

                            $image = '<li class="tm-timline-thumb" style="background-image: url('. esc_url($related_thumb[0]).')"></li>';

                            if( $timeline_counter%2 )
                            {
                                echo $image;
                            }
                            ?>

                            <li class="tm-timline-text" style="background: <?php echo esc_attr($timeline_background_color); ?>; color: <?php echo esc_attr($timeline_text_color); ?>">
                                <div class="tm-timline-content">
                                    <div class="tm-timline-month"><?php echo get_the_date('F'); ?></div>
                                    <div class="tm-timline-year"><?php echo get_the_date('Y'); ?></div>
                                    <h2><?php the_title(); ?></h2>
                                </div>
                            </li>

                            <?php

                            if( !($timeline_counter%2) )
                            {
                                echo $image;
                            }

                        endwhile; ?>
                    </ul>
                </div>

                <a href="" class="uk-slidenav uk-slidenav-contrast uk-slidenav-previous" data-uk-slider-item="previous"></a>
                <a href="" class="uk-slidenav uk-slidenav-contrast uk-slidenav-next" data-uk-slider-item="next"></a>

            </div>
        </div>

    <?php endif;

    wp_reset_query();
    $content = ob_get_contents();
    ob_end_clean();

    return $content;
}

add_shortcode("eclat_timeline", "eclat_timeline_shortcode");

