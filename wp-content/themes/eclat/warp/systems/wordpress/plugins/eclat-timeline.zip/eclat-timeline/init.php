<?php
/*
Plugin Name: Eclat Timeline
Plugin URI: http://www.elartica.com/plugins/timeline/
Description: With the help of this plugin you can add section timeline
Author: Elartica Team
Author URI: http://www.elartica.com
Text Domain: eclat-timeline
Domain Path: /languages/
Version: 1.0.0
*/

define( 'ECLAT_TIMELINE_VERSION', '1.0.0' );
define( 'ECLAT_TIMELINE_TAXONOMY', 'timeline-category');
define( 'ECLAT_TIMELINE_POST_TYPE', 'timeline');
define( 'ECLAT_TIMELINE_PLUGIN_PATH', dirname(__FILE__));
define( 'ECLAT_TIMELINE_PLUGIN_URL', untrailingslashit( plugins_url( '/', __FILE__ ) ));
define( 'ECLAT_TIMELINE_PLUGIN_SHORTCODES_PATH', ECLAT_TIMELINE_PLUGIN_PATH .  '/includes/ShortCodes' );

// Loaded this plugin
add_action( 'plugins_loaded', function(){
    load_plugin_textdomain( 'eclat-timeline', false, dirname( plugin_basename( __FILE__ ) ). '/languages/' );
} );

include_once(ECLAT_TIMELINE_PLUGIN_PATH.'/includes/functions.php');

// Start up this post type
add_action( 'init', function()
{
    eclat_timeline_register_post_types();
    eclat_timeline_register_taxonomy();

    add_filter( 'manage_edit-timeline_columns', 'eclat_timeline_edit_columns' );
    add_action( 'manage_posts_custom_column', 'eclat_timeline_custom_columns' );

    add_theme_support('post-thumbnails');
    set_post_thumbnail_size(110, 110, true);

    // for thumbnail preview in the admin screen
    if (function_exists('add_theme_support') && "timeline" == eclat_timeline_get_current_post_type())
    {
        add_filter( 'manage_posts_columns', 'eclat_timeline_add_thumbnail_column' );
        add_action( 'manage_posts_custom_column', 'eclat_timeline_add_thumbnail_value', 10, 2 );
    }

    // Add Extra Custom Fields to the Post Type Add / Edit screen
    add_action( 'admin_init', 'eclat_timeline_admin_init' );
    add_action( 'save_post', 'eclat_timeline_save_details' );

    // Add Columns to the TimeLine Categories Screen
    add_filter("manage_edit-timeline-category_columns", 'eclat_timeline_manage_categories');
    add_filter("manage_timeline-category_custom_column", 'eclat_timeline_manage_columns', 10, 3);

    // load shortcodes
    include_once(ECLAT_TIMELINE_PLUGIN_SHORTCODES_PATH.'/eclat-timeline.php');

    // Visual Composer
    if (class_exists('WPBakeryVisualComposerAbstract'))
    {
        include_once(ECLAT_TIMELINE_PLUGIN_SHORTCODES_PATH.'/VisualComposer/eclat-timeline.php');
    }


} );