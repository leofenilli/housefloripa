<?php
/**
 * @package   Eclat TimeLine
 * @author    Elartica Team http://www.elartica.com
 * @copyright Copyright (C) Elartica Team
 * @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
 */

// register post types
function eclat_timeline_register_post_types()
{
    $timeline_labels = array(
        'name' 					=> esc_html__('Timeline', 'eclat-timeline'),
        'singular_name' 		=> esc_html__('Timeline Item', 'eclat-timeline'),
        'add_new' 				=> esc_html__('Add New', 'eclat-timeline'),
        'add_new_item' 			=> esc_html__('Add New Timeline item', 'eclat-timeline'),
        'edit_item' 			=> esc_html__('Edit Timeline item', 'eclat-timeline'),
        'new_item' 				=> esc_html__('New Timeline item', 'eclat-timeline'),
        'all_items' 			=> esc_html__('All Timeline items', 'eclat-timeline'),
        'view_item' 			=> esc_html__('View Timeline item', 'eclat-timeline'),
        'search_items' 			=> esc_html__('Search Timeline item', 'eclat-timeline'),
        'not_found' 			=> esc_html__('No Timeline item found', 'eclat-timeline'),
        'not_found_in_trash' 	=> esc_html__('No Timeline item found in Trash', 'eclat-timeline'),
        'parent_item_colon' 	=> ''
    );

    $timeline_args = array(
        'labels'                => $timeline_labels,
        'singular_label'        => esc_html__('timeline', 'eclat-timeline'),
        'public'                => true,
        'show_ui'               => true,
        'show_in_nav_menus'     => false,
        'capability_type'       => 'post',
        'hierarchical'          => false,
        'rewrite'               => true,
        'menu_icon'				=> 'dashicons-calendar',
        'menu_position'			=> 20,
        'exclude_from_search' 	=> true,
        'supports'              => array('title', 'editor', 'thumbnail')
    );

    register_post_type('timeline',$timeline_args);
}

// register taxonomy
function eclat_timeline_register_taxonomy()
{
    $taxonomy_labels = array(
        'name'                       => esc_html__('Timeline Categories', 'eclat-timeline'),
        'singular_name'              => esc_html__('Timeline Category', 'eclat-timeline'),
        'search_items'               => esc_html__('Search Timeline Categories', 'eclat-timeline'),
        'popular_items'              => esc_html__('Popular Timeline Categories', 'eclat-timeline'),
        'all_items'                  => esc_html__('All Timeline Categories', 'eclat-timeline'),
        'edit_item'                  => esc_html__('Edit Timeline Category', 'eclat-timeline'),
        'update_item'                => esc_html__('Update Timeline Category', 'eclat-timeline'),
        'add_new_item'               => esc_html__('Add New Timeline Category', 'eclat-timeline'),
        'new_item_name'              => esc_html__('New Timeline Category Name', 'eclat-timeline'),
        'separate_items_with_commas' => esc_html__('Separate Timeline Categories with commas', 'eclat-timeline'),
        'add_or_remove_items'        => esc_html__('Add or remove Timeline Categories', 'eclat-timeline'),
        'choose_from_most_used'      => esc_html__('Choose from the most used Timeline Categories', 'eclat-timeline'),
        'not_found'                  => esc_html__('No Timeline Category found.', 'eclat-timeline'),
        'menu_name'                  => esc_html__('Timeline Categories', 'eclat-timeline'),
    );

    register_taxonomy("timeline-category", array("timeline"), array(
        "hierarchical" => true,
        "labels" => $taxonomy_labels,
        "rewrite" => array("slug" => "timeline-category")
    ));
}

// add custom columns to the admin acreen
function eclat_timeline_custom_columns($column)
{
    global $post;

    if ("post_id" == $column) echo $post->ID;
    elseif ("description" == $column) echo substr($post->post_content, 0, 100).'...';
    elseif ("thumbnail" == $column) echo $post->post_thumbnail;
    elseif("category" == $column)
    {
        $categories = get_the_terms(0, "timeline-category");
        if(!is_array($categories)) return;
        $category = reset($categories);
        if(is_object($category))
        {
            echo $category->name;
        }
    }
}

function eclat_timeline_edit_columns($columns)
{
    $columns = array(
        "cb" 			=> "<input type=\"checkbox\" />",
        "title" 		=> esc_html__('Title', 'eclat-timeline'),
        "thumb" 	    => esc_html__('Thumbnail', 'eclat-timeline'),
        "description" 	=> esc_html__('Description', 'eclat-timeline'),
        "category" 		=> esc_html__('Category', 'eclat-timeline'),
        "date" 			=> esc_html__('Date', 'eclat-timeline'),
    );
    return $columns;
}

// for thumbnail preview in the admin screen
function eclat_timeline_add_thumbnail_column($cols)
{
    $cols['thumb'] = esc_html__('Thumbnail', 'eclat-timeline');
    return $cols;
}

function eclat_timeline_add_thumbnail_value($column_name, $post_id)
{
    $width = (int)110;
    $height = (int)110;

    if ('thumb' == $column_name) {
        $thumbnail_id = get_post_meta($post_id, '_thumbnail_id', true);
        $attachments = get_children(array('post_parent' => $post_id, 'post_type' => 'attachment', 'post_mime_type' => 'image'));

        if ($thumbnail_id) {
            $thumb = wp_get_attachment_image($thumbnail_id, array($width, $height), true);
        } elseif ($attachments) {
            foreach ($attachments as $attachment_id => $attachment) {
                $thumb = wp_get_attachment_image($attachment_id, array($width, $height), true);
            }
        }

        if (isset($thumb) && $thumb) {
            echo $thumb;
        } else {
            echo esc_html__('None', 'eclat-timeline');
        }
    }
}


// Add Extra Custom Fields to the Post Type Add / Edit screen
function eclat_timeline_admin_init()
{
    add_meta_box("timeline_meta_box", "Timeline Item Options", "eclat_timeline_meta_options", "timeline", "normal", "low");
}

function get_eclat_timeline_meta_boxes_fields()
{
    $meta_boxes_fields = array(
        'timeline-text-color' => array(
            'label' => esc_html__( 'Text Color', 'eclat-timeline' ),
            'desc' => esc_html__( 'Timeline item text color', 'eclat-timeline' ),
            'type' => 'colorpicker',
        ),
        'timeline-background-color' => array(
            'label' => esc_html__( 'Background Color', 'eclat-timeline' ),
            'desc' => esc_html__( 'Timeline item background color', 'eclat-timeline' ),
            'type' => 'colorpicker',
        )
    );

    return $meta_boxes_fields;
}

function eclat_timeline_meta_options()
{
    $meta_boxes_fields = get_eclat_timeline_meta_boxes_fields();
    global $post;
    echo '<input type="hidden" name="eclat_timeline_meta_boxes_nonce" value="'.wp_create_nonce('eclat_timeline_meta_boxes_nonce').'" />';

    echo '<table class="form-table">';
    foreach ($meta_boxes_fields as $key => $field)
    {
        $meta = get_post_meta($post->ID, $key, true);
        echo '<tr>
                <th><label for="'.$key.'">'.$field['label'].'</label></th>
                <td>';
        switch($field['type']) {
            case 'text':
                echo '<input type="text" name="'.$key.'" id="'.$key.'" value="'.$meta.'" size="30" /><br /><span class="description">'.$field['desc'].'</span>';
                break;
            case 'textarea':
                echo '<textarea type="text" name="'.$key.'" id="'.$key.'" rows="10" cols="45">'.$meta.'</textarea><br /><span class="description">'.$field['desc'].'</span>';
                break;
            case 'checkbox':
                echo '<input type="checkbox" name="'.$key.'" id="'.$key.'" '.($meta ? 'checked="checked"' : '').'/><label for="'.$key.'">'.$field['desc'].'</label>';
                break;
            case 'colorpicker':
                wp_enqueue_script('wp-color-picker');
                wp_enqueue_style( 'wp-color-picker' );
                echo '<input name="'.$key.'" type="text" id="'.$key.'" value="'.($meta ? $meta : '#fab000').'" data-default-color="#80d8ff" size="30">
                <script type="text/javascript">
                jQuery(document).ready(function($) { $("#'.$key.'").wpColorPicker(); });
                </script>
                ';
                break;
            case 'select':
                echo '<select name="'.$key.'" id="'.$key.'">';
                foreach ($field['options'] as $option) {
                    echo '<option', $meta == $option['value'] ? ' selected="selected"' : '', ' value="'.$option['value'].'">'.$option['label'].'</option>';
                }
                echo '</select><br /><span class="description">'.$field['desc'].'</span>';
                break;
        }
        echo '</td></tr>';
    }
    echo '</table>';
}

function eclat_timeline_save_details($post_id)
{
    $meta_boxes_fields = get_eclat_timeline_meta_boxes_fields();

    if(!isset($_REQUEST['eclat_timeline_meta_boxes_nonce']))
        return $post_id;

    if (!wp_verify_nonce($nonce, 'eclat_timeline_meta_boxes_nonce'))
        return $post_id;

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
        return $post_id;

    if ('page' == $_REQUEST['post_type'])
    {
        if (!current_user_can('edit_page', $post_id))
            return $post_id;
    }
    elseif (!current_user_can('edit_post', $post_id))
    {
        return $post_id;
    }

    foreach ($meta_boxes_fields as $key => $field)
    {
        $old = get_post_meta($post_id, $key, true);
        $new = $_REQUEST[$key];

        if ($new && $new != $old)
        {
            update_post_meta($post_id, $key, $new);
        }
        elseif ('' == $new && $old)
        {
            delete_post_meta($post_id, $key, $old);
        }
    }
}

// Add Columns to the portfolio categories screen
function eclat_timeline_manage_categories($columns)
{
    $new_columns = array(
        'cb' 			=> '<input type="checkbox" />',
        'ID'			=> esc_html__('ID', 'eclat-timeline'),
        'name' 			=> esc_html__('Name', 'eclat-timeline'),
        'slug' 			=> esc_html__('Slug', 'eclat-timeline'),
        'shortcode' 	=> esc_html__('Shortcode', 'eclat-timeline'),
        'posts' 		=> esc_html__('Posts', 'eclat-timeline')
    );
    return $new_columns;
}

function eclat_timeline_manage_columns($output, $column_name, $id)
{
    $column = get_term($id, 'timeline-category');

    switch ($column_name)
    {
        case 'shortcode':
            $output .= '[eclat_timeline category="'.$id.'"]';
            break;
        case 'ID':
            $output .= $id;
            break;
        default:
            break;
    }
    return $output;
}

// gets the current post type in the WordPress Admin
function eclat_timeline_get_current_post_type() {
    global $post, $typenow, $current_screen;

    //we have a post so we can just get the post type from that
    if ( $post && $post->post_type )
        return $post->post_type;

    //check the global $typenow - set in admin.php
    elseif( $typenow )
        return $typenow;

    //check the global $current_screen object - set in sceen.php
    elseif( $current_screen && $current_screen->post_type )
        return $current_screen->post_type;

    //lastly check the post_type querystring
    elseif( isset( $_REQUEST['post_type'] ) )
        return sanitize_key( $_REQUEST['post_type'] );

    //we do not know the post type!
    return null;
}

?>