<?php

$category_list = get_terms('timeline-category', array(
    'hide_empty' 	=> false,
    'order_by'		=> 'name',
    'pad_counts'	=> true
));

$category_list_array = array( esc_html__('Show All', 'eclat-timeline') => 'all' );

foreach($category_list as $category)
{
    $category_list_array[htmlspecialchars_decode($category->name) . ' (' . $category->count . ')'] = $category->term_id;
}

// [eclat_timeline]
vc_map(array(
    "name"			=> esc_html__( "TimeLine", "eclat-timeline" ),
    "category"		=> 'Content',
    "description"	=> esc_html__( "Place TimeLine", "eclat-timeline" ),
    "base"			=> "eclat_timeline",
    "class"			=> "",
    "icon"			=> "eclat_timeline",

    "params" 	=> array(

        array(
            "type"			=> "textfield",
            "heading"		=> esc_html__( "How many items would you like to show?", "eclat-timeline" ),
            "param_name"	=> "number",
            "value"			=> "10"
        ),

        array(
            "type"			=> "dropdown",
            "heading"		=> esc_html__( "How many items would you like to show in line?", "eclat-timeline" ),
            "param_name"	=> "visible_item",
            "value"			=> array(
                "5"			=> "5",
                "4"			=> "4",
                "3"			=> "3"
            ),
            "std"			=> "5"
        ),

        array(
            "type"			=> "dropdown",
            "heading"		=> esc_html__( "Timeline Category", "eclat-timeline" ),
            "param_name"	=> "category",
            "value"			=> $category_list_array
        ),

        array(
            "type"			=> "dropdown",
            "heading"		=> esc_html__( "Order By", "eclat-timeline" ),
            "param_name"	=> "orderby",
            "value"			=> array(
                esc_html__( "None", "eclat-timeline" )			    => "none",
                esc_html__( "Sort by ID", "eclat-timeline" )		    => "ID",
                esc_html__( "Sort alphabetically", "eclat-timeline" )	=> "title",
                esc_html__( "Sort by most recent", "eclat-timeline" )	=> "date",
                esc_html__( "Random", "eclat-timeline" )	            => "rand"
            ),
            "std"			=> "date"
        ),

        array(
            "type"			=> "dropdown",
            "heading"		=> esc_html__( "Sorting", "eclat-timeline" ),
            "param_name"	=> "order",
            "value"			=> array(
                esc_html__( "Descending", "eclat-timeline" ) => "desc",
                esc_html__( "Crescent", "eclat-timeline" )	  => "asc"
            ),
            "std"			=> "desc"
        ),

        array(
            "type"			=> "dropdown",
            "heading"		=> esc_html__( "Center", "eclat-timeline" ),
            "param_name"	=> "center",
            "value"			=> array(
                esc_html__( "No", "eclat-timeline" )	=> "false",
                esc_html__( "Yes", "eclat-timeline" )	=> "true"
            ),
            "std"			=> "false",
            "description"   => esc_html__( "Center items mode.", "eclat-timeline" )
        ),

        array(
            "type"			=> "dropdown",
            "heading"		=> esc_html__( "Infinite", "eclat-timeline" ),
            "param_name"	=> "infinite",
            "value"			=> array(
                esc_html__( "No", "eclat-timeline" )	=> "false",
                esc_html__( "Yes", "eclat-timeline" )	=> "true"
            ),
            "std"			=> "true",
            "description"   => esc_html__( "Infinite scrolling.", "eclat-timeline" )
        ),

        array(
            "type"			=> "dropdown",
            "heading"		=> esc_html__( "Auto play", "eclat-timeline" ),
            "param_name"	=> "autoplay",
            "value"			=> array(
                esc_html__( "No", "eclat-timeline" )	=> "false",
                esc_html__( "Yes", "eclat-timeline" )	=> "true"
            ),
            "std"			=> "false",
            "description"   => esc_html__( "Defines whether or not the slider items should switch automatically.", "eclat-timeline" )
        ),

        array(
            "type"			=> "dropdown",
            "heading"		=> esc_html__( "Pause on hover", "eclat-timeline" ),
            "param_name"	=> "pause",
            "value"			=> array(
                esc_html__( "Yes", "eclat-timeline" )	=> "true",
                esc_html__( "No", "eclat-timeline" )	=> "false"
            ),
            "std"			=> "true",
            "dependency" 	=> Array(
                "element"   => "autoplay",
                "value"     => array("true")
            ),
            "description"   => esc_html__( "Pause autoplay when hovering a slider.", "eclat-timeline" )
        ),

        array(
            "type"			=> "textfield",
            "heading"		=> esc_html__( "Autoplay Interval", "eclat-timeline" ),
            "param_name"	=> "autoplayinterval",
            "value"			=> "7000",
            "std"			=> "7000",
            "dependency" 	=> Array(
                "element"   => "autoplay",
                "value"     => array("true")
            ),
            "description"   => esc_html__( "Defines the timespan between switching slider items.", "eclat-timeline" )
        ),
    )

));
